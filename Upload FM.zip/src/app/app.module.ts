import { NgModule }      from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { rootRouterConfig } from './app.routes';
import { BrowserModule } from '@angular/platform-browser';
import { UploaderComponent } from '@syncfusion/ej2-ng-inputs';
import { AppComponent }  from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplateComponent } from './ng-template/template.component';
import { TemplateDrivenComponent } from './template-driven-form/template-driven.component';
import { ReactiveComponent } from './reactive-form/reactive.component';
import { Newcomponent } from './dynamic-injection/childComponent';
import { DynamicInjComponent } from './dynamic-injection/dynamicInj.component';

// const appRoutes: Routes = [
//   { path: 'ng-content', component: NgContentComponent }
// ];

@NgModule({
  imports:      [ BrowserModule, RouterModule.forRoot(rootRouterConfig, { useHash: true }), 
    FormsModule,
    ReactiveFormsModule,],
  declarations: [ AppComponent, DynamicInjComponent, UploaderComponent, Newcomponent, TemplateComponent, ReactiveComponent, TemplateDrivenComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }

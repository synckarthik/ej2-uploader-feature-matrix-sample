import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

class User {
  constructor(
    // public time: Date,
    public fileName: string,
  ) {}
}

@Component({
  selector: 'sample',
  styleUrls: ['./template-driven.component.css'],
  templateUrl:'./template-driven.component.html' 
})

export class TemplateDrivenComponent {
  public serverUrl: any = {
    saveUrl: 'http://localhost:50272/api/uploadbox/Save',
    removeUrl: 'http://localhost:50272/api/uploadbox/Remove'
  }
   user: User;
  
  ngOnInit() {
    this.user = new User(null);
  }

  onFormSubmit() {
    debugger;
  }

  onFileSelect(args: any) {
   this.user.fileName = args.filesData[0].name;
  }

}

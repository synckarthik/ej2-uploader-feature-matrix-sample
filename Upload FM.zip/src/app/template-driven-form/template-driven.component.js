"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var User = (function () {
    function User(
        // public time: Date,
        fileName) {
        this.fileName = fileName;
    }
    return User;
}());
var TemplateDrivenComponent = (function () {
    function TemplateDrivenComponent() {
        this.serverUrl = {
            saveUrl: 'http://localhost:50272/api/uploadbox/Save',
            removeUrl: 'http://localhost:50272/api/uploadbox/Remove'
        };
    }
    TemplateDrivenComponent.prototype.ngOnInit = function () {
        this.user = new User(null);
    };
    TemplateDrivenComponent.prototype.onFormSubmit = function () {
        debugger;
    };
    TemplateDrivenComponent.prototype.onFileSelect = function (args) {
        this.user.fileName = args.filesData[0].name;
    };
    return TemplateDrivenComponent;
}());
TemplateDrivenComponent = __decorate([
    core_1.Component({
        selector: 'sample',
        styleUrls: ['./template-driven.component.css'],
        templateUrl: './template-driven.component.html'
    })
], TemplateDrivenComponent);
exports.TemplateDrivenComponent = TemplateDrivenComponent;
//# sourceMappingURL=template-driven.component.js.map
import { Routes } from '@angular/router';

import { TemplateComponent } from './ng-template/template.component';
import { TemplateDrivenComponent } from './template-driven-form/template-driven.component';
import { ReactiveComponent } from './reactive-form/reactive.component';
import { DynamicInjComponent } from './dynamic-injection/dynamicInj.component'

export const rootRouterConfig: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'ng-template', component: TemplateComponent },
  { path: 'template-driven-form', component: TemplateDrivenComponent },
  { path: 'reactive-form', component: ReactiveComponent },
  { path: 'dynamic-injection', component: DynamicInjComponent }
];
